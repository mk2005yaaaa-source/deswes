// ---------------------------------------------------------------------------
// desweb — content data
// All copy sourced from Mohan Kumar's portfolio brief. Testimonials are
// clearly flagged as sample/placeholder — swap in real client quotes as they
// come in (see `isSample` flag below).
// ---------------------------------------------------------------------------

export const brand = {
  name: "desweb",
  person: "Mohan Kumar",
  role: "Freelance Web Designer",
  disciplines: [
    "Web Designer",
    "UI/UX Designer",
    "Graphic Designer",
    "Video Editor",
    "3D Artist",
    "Content Writer",
  ],
  location: "Chennai, Tamil Nadu, India",
  tagline: "Creating digital experiences that help businesses grow.",
  description:
    "I create premium digital experiences that help businesses grow through thoughtful design, high-performance websites, branding, visual content, and creative solutions.",
  email: "saravananvmohankumar@gmail.com",
  phone: "+91 63821 07170",
  whatsapp: "916382107170",
  github: "https://github.com/Mohan449",
};

export const stats = [
  { value: 25, suffix: "+", label: "Services Offered" },
  { value: 3, suffix: "", label: "Full Production Builds" },
  { value: 6, suffix: "", label: "Disciplines Covered" },
  { value: 100, suffix: "%", label: "Direct Communication" },
];

export const about = {
  heading: "About Me",
  eyebrow: "// get-to-know-me",
  paragraphs: [
    "I build the things a growing business actually needs — a website that works, a brand that looks considered, and content that reads like it was written for real people.",
    "My work sits at the intersection of design and development. I don't just hand over a mockup and walk away — I design interfaces, build them into working websites, and follow through with the graphics, documents, and copy that make a launch feel complete. Most small businesses don't need five different freelancers; they need one person who understands how it all fits together.",
    "Recent work includes a full production e-commerce platform built for a Chennai-based sarees brand, an AI-powered quiz platform, and a student performance tracking system built for real classroom use. Each project taught the same lesson: good design only matters if it's usable, fast, and built to actually ship.",
    "If you're looking for someone who can take a project from a rough idea to a finished, professional result — and communicate clearly the whole way through — that's the freelancer I aim to be.",
  ],
  meta: [
    { label: "Based In", value: "Chennai, Tamil Nadu" },
    { label: "Core Disciplines", value: "Web, UI/UX, Graphic Design, Video, 3D, Content Writing" },
    { label: "Tools", value: "Figma, Canva, Next.js, Photoshop, Premiere, Blender" },
    { label: "Working With", value: "Startups & small businesses wanting agency-quality work" },
  ],
};

export const whyChooseMe = [
  {
    title: "Client-First Approach",
    description: "Every project starts with your goals, not a template. I design around what your business actually needs.",
  },
  {
    title: "Fast, Reliable Delivery",
    description: "Clear timelines, regular updates, and no disappearing acts — you always know where your project stands.",
  },
  {
    title: "Full-Range Skillset",
    description: "Web, design, video and content under one roof, so your brand stays visually and tonally consistent.",
  },
  {
    title: "Attention to Detail",
    description: "Spacing, copy, colour, code — the small things are usually what separate good work from great work.",
  },
  {
    title: "Clear Communication",
    description: "Straightforward updates in plain language, with no jargon and no guessing games about progress.",
  },
  {
    title: "Fair, Transparent Pricing",
    description: "Packages built for small businesses and individuals, with no hidden costs or scope surprises.",
  },
  {
    title: "Long-Term Support",
    description: "Post-delivery support and revisions, because a website or brand should keep working long after launch.",
  },
  {
    title: "Modern, Considered Design",
    description: "Contemporary layouts and visual language that feel current — never generic or dated.",
  },
];

export const process = [
  { step: "01", title: "Consultation", description: "We start with a short conversation about your business, your goals, and what success looks like for this project." },
  { step: "02", title: "Research", description: "I look into your industry, competitors, and audience so the design direction is grounded in more than personal taste." },
  { step: "03", title: "Planning", description: "A clear scope, timeline, and structure is put together before any design work begins, so there are no surprises later." },
  { step: "04", title: "Design", description: "Concepts are built out with attention to layout, typography, and brand consistency, shared with you at each milestone." },
  { step: "05", title: "Review", description: "You review the work in progress and share feedback openly — this stage is a conversation, not a one-way handoff." },
  { step: "06", title: "Revisions", description: "Adjustments are made based on your feedback until the direction feels right, not just technically finished." },
  { step: "07", title: "Final Delivery", description: "Finished files, source assets, and a walkthrough are delivered in the format your team can actually use." },
  { step: "08", title: "Support", description: "I stay available after delivery for questions, small fixes, and guidance as your project goes live." },
];

export type Service = {
  id: string;
  category: string;
  title: string;
  description: string;
  benefits: string[];
  process: string[];
};

export const services: Service[] = [
  { id: "web-design-dev", category: "Web", title: "Website Design & Development", description: "Full custom websites built from scratch, designed around your brand and built to load fast and work properly on every device.", benefits: ["Mobile-responsive by default", "Clean, maintainable code", "SEO-friendly structure"], process: ["Wireframe & sitemap", "Visual design", "Development & testing", "Launch"] },
  { id: "uiux", category: "Web", title: "UI/UX Design", description: "Interface design that balances how a product looks with how it actually gets used, backed by real usability thinking.", benefits: ["Intuitive navigation", "Consistent design system", "Higher user retention"], process: ["User flow mapping", "Wireframes", "High-fidelity UI", "Prototype testing"] },
  { id: "landing-page", category: "Web", title: "Landing Page Design", description: "Focused, single-purpose pages built to convert visitors — for launches, campaigns, or lead generation.", benefits: ["Clear call-to-action focus", "Fast load times", "Built for conversion"], process: ["Goal definition", "Copy & layout draft", "Design build", "Conversion review"] },
  { id: "logo", category: "Branding", title: "Logo Design", description: "A distinct, versatile mark that represents your business clearly across digital and print, in colour and in black & white.", benefits: ["Memorable and unique", "Scales from favicon to signage", "Multiple format delivery"], process: ["Discovery & research", "Concept sketches", "Digital refinement", "Final files & guide"] },
  { id: "brand-identity", category: "Branding", title: "Brand Identity", description: "A full identity system — colour palette, typography, logo usage, and tone — so your brand feels the same everywhere.", benefits: ["Consistent brand recognition", "Ready-to-use style guide", "Professional first impression"], process: ["Brand strategy session", "Visual direction", "Identity system build", "Brand guideline document"] },
  { id: "posters", category: "Print", title: "Poster Design", description: "Eye-catching posters for events, promotions, or campaigns, designed to communicate the message at a glance.", benefits: ["Strong visual hierarchy", "Print & digital ready", "Fast turnaround"], process: ["Brief & concept", "Layout design", "Revisions", "Print-ready export"] },
  { id: "flyers", category: "Print", title: "Business Flyers", description: "Compact, informative flyers for offers, services, or announcements that stay on-brand and easy to read.", benefits: ["Clear, scannable layout", "On-brand colour & type", "Digital + print formats"], process: ["Content gathering", "Layout draft", "Refinement", "Final export"] },
  { id: "brochures", category: "Print", title: "Brochures", description: "Multi-page or fold-out brochures that present your business, services, or catalogue in a polished format.", benefits: ["Organised information flow", "Professional print finish", "Reusable template structure"], process: ["Content structure", "Design layout", "Review", "Print-ready files"] },
  { id: "banners", category: "Print", title: "Banner Design", description: "Web banners, event banners, and signage graphics sized correctly for their intended placement.", benefits: ["Correct sizing for platform", "Consistent brand presence", "Quick delivery"], process: ["Spec confirmation", "Design draft", "Revisions", "Final delivery"] },
  { id: "social-media", category: "Print", title: "Social Media Designs", description: "Templated and one-off post designs for Instagram, Facebook, and LinkedIn that keep your feed consistent.", benefits: ["On-brand templates", "Platform-correct sizing", "Faster content turnaround"], process: ["Content calendar input", "Template design", "Batch creation", "Delivery"] },
  { id: "yt-thumbnails", category: "Print", title: "YouTube Thumbnail Design", description: "High-contrast, click-worthy thumbnails designed to stand out in a crowded feed without misleading viewers.", benefits: ["Higher click-through rate", "Consistent channel branding", "Fast delivery per video"], process: ["Video context review", "Concept draft", "Design", "Final export"] },
  { id: "video-editing", category: "Video", title: "Video Editing", description: "Editing for promotional videos, reels, and YouTube content — cuts, pacing, colour, and sound cleanup.", benefits: ["Polished, professional pacing", "Colour & audio correction", "Platform-ready exports"], process: ["Footage review", "Rough cut", "Colour & sound pass", "Final render"] },
  { id: "motion-graphics", category: "Video", title: "Motion Graphics", description: "Animated titles, lower-thirds, and short motion pieces that add production value to video and social content.", benefits: ["Adds polish to video content", "Reusable animated templates", "Brand-consistent motion style"], process: ["Concept & storyboard", "Animation build", "Revisions", "Final export"] },
  { id: "3d-modeling", category: "3D", title: "3D Modeling", description: "Custom 3D models built for visualization, product concepts, or animation, from simple objects to detailed assets.", benefits: ["Accurate proportions & detail", "Reusable across projects", "Multiple export formats"], process: ["Reference & brief", "Base modeling", "Detail & texturing", "Final export"] },
  { id: "3d-product-modeling", category: "3D", title: "3D Product Modeling", description: "Product-accurate 3D models built specifically for e-commerce, catalogues, or marketing use.", benefits: ["True-to-product accuracy", "E-commerce ready", "Consistent lighting setup"], process: ["Product reference", "Modeling", "Texturing", "Render-ready file"] },
  { id: "product-rendering", category: "3D", title: "Product Scene Rendering", description: "Photorealistic scene renders that place your product in a styled environment without a physical photoshoot.", benefits: ["Photoreal without a studio shoot", "Full creative control of scene", "High-resolution output"], process: ["Scene concept", "Lighting & render setup", "Draft render", "Final high-res render"] },
  { id: "product-mockups", category: "3D", title: "Product Mockups", description: "Realistic product mockups — packaging, apparel, devices — for presenting designs before production.", benefits: ["Client-ready presentation", "No physical prototype needed", "Fast iteration on designs"], process: ["Mockup selection", "Design placement", "Lighting & detail pass", "Final delivery"] },
  { id: "resume", category: "Documents", title: "Resume Design", description: "Clean, ATS-friendly resume layouts that present experience clearly without sacrificing visual polish.", benefits: ["ATS-compatible structure", "Clear visual hierarchy", "Tailored to your industry"], process: ["Content review", "Layout design", "Formatting pass", "Final PDF & editable file"] },
  { id: "business-docs", category: "Documents", title: "Business Documents", description: "Proposals, reports, letterheads, and internal documents formatted to look professional and on-brand.", benefits: ["Consistent brand formatting", "Professional client impression", "Reusable templates"], process: ["Content structure", "Template design", "Formatting", "Final files"] },
  { id: "presentations", category: "Documents", title: "Presentation Design", description: "Pitch decks and presentation slides designed for clarity, with a visual narrative that supports your message.", benefits: ["Clear visual storytelling", "Investor/client-ready polish", "Editable slide templates"], process: ["Content & outline review", "Slide design", "Revisions", "Final deck delivery"] },
  { id: "content-writing", category: "Content", title: "Content Writing", description: "General-purpose writing for websites, articles, and marketing materials in a clear, natural tone.", benefits: ["Human, natural tone", "Consistent brand voice", "Ready to publish"], process: ["Brief & research", "First draft", "Revisions", "Final copy"] },
  { id: "website-copy", category: "Content", title: "Website Copywriting", description: "Homepage, about, and service page copy written to explain your business clearly and guide visitors to act.", benefits: ["Clear, persuasive messaging", "Consistent with brand voice", "Structured for web reading"], process: ["Discovery call", "Content structure", "Draft & review", "Final copy"] },
  { id: "seo-blog", category: "Content", title: "SEO Blog Writing", description: "Blog content researched and structured around search intent, written for readers first and search engines second.", benefits: ["Search-friendly structure", "Genuinely useful content", "Builds long-term organic traffic"], process: ["Keyword & topic research", "Outline", "Draft", "Edit & final polish"] },
  { id: "product-desc", category: "Content", title: "Product Description Writing", description: "Clear, benefit-led product descriptions for e-commerce listings that help customers decide with confidence.", benefits: ["Benefit-focused writing", "Consistent catalogue tone", "Improved listing clarity"], process: ["Product research", "Draft descriptions", "Review", "Final copy set"] },
  { id: "social-copy", category: "Content", title: "Social Media Content Writing", description: "Captions and copy for social posts that match your brand voice across platforms.", benefits: ["Consistent brand voice", "Platform-appropriate tone", "Ready-to-post captions"], process: ["Content calendar input", "Draft captions", "Review", "Final delivery"] },
];

export const serviceCategories = ["All", "Web", "Branding", "Print", "Video", "3D", "Documents", "Content"];

export type Project = {
  id: string;
  isReal: boolean;
  title: string;
  category: string;
  type: string;
  role: string;
  tools: string[];
  objective: string;
  approach: string;
  outcome: string;
};

export const projects: Project[] = [
  {
    id: "nathuz-sarees",
    isReal: true,
    title: "Nathuz Sarees — E-Commerce Platform",
    category: "Web Development",
    type: "Nathuz Sarees · Fashion & Retail",
    role: "Full-Stack Design & Development",
    tools: ["Next.js 14", "TypeScript", "Tailwind", "Prisma", "PostgreSQL", "Vercel"],
    objective: "Nathuz Sarees needed a production-ready online storefront that could showcase their saree collection, handle real orders, and feel as premium online as the product does in person.",
    approach: "Built the full platform from the ground up — a catalogue and product structure using PostgreSQL and Prisma, a clean storefront UI in Next.js and Tailwind, and a checkout flow designed to keep the buying process short and mobile-friendly.",
    outcome: "A fast, deployed, mobile-first e-commerce site (hosted on Vercel) giving the brand a proper digital storefront — built and maintained as a live production system, not a template.",
  },
  {
    id: "quiz-platform",
    isReal: true,
    title: "Quiz & Assessment Platform",
    category: "Web Development",
    type: "EdTech / Personal Product",
    role: "Full-Stack Developer & UI Designer",
    tools: ["Next.js", "PostgreSQL", "Prisma", "NextAuth", "Cloudinary"],
    objective: "Build a full-stack quiz platform that could generate and grade quizzes intelligently, rather than relying on static question banks.",
    approach: "Integrated a content-generation service for question creation, Cloudinary for media handling, and a Prisma/PostgreSQL backend for user data and results, with accessible UI components and NextAuth for secure login.",
    outcome: "A working, end-to-end product covering authentication, dynamic content generation, and results tracking — a complete demonstration of taking a product from database schema to finished interface.",
  },
  {
    id: "lms-tracker",
    isReal: true,
    title: "Student Performance Tracking & LMS",
    category: "Web Development",
    type: "Education / Learning Management",
    role: "Full-Stack Developer",
    tools: ["React", "Node.js", "Express", "MongoDB"],
    objective: "Give students and educators a clear, motivating way to track academic performance over time — not just a static gradebook.",
    approach: "Built with a React front end and a Node.js/Express/MongoDB backend, the system layers in gamification elements and smart insights so performance tracking feels engaging rather than administrative.",
    outcome: "A functioning LMS covering the full stack — data modelling, API design, and an interface built for daily classroom use.",
  },
  {
    id: "ui-concepts",
    isReal: false,
    title: "UI Concepts & Brand Identity",
    category: "UI/UX",
    type: "Sample / Concept Work",
    role: "UI & Brand Designer",
    tools: ["Figma", "Illustrator"],
    objective: "Demonstrate range across mobile app interface design and standalone brand identity concepts.",
    approach: "A mobile app UI concept exploring clean onboarding flows, alongside a logo and brand identity concept built around a simple, versatile mark and colour system.",
    outcome: "A pair of concept pieces showing UI and branding thinking outside of a live client engagement.",
  },
  {
    id: "poster-collection",
    isReal: false,
    title: "Poster Collection — Social, Business, Event & Festival",
    category: "Graphics",
    type: "Sample / Concept Work",
    role: "Graphic Designer",
    tools: ["Photoshop", "Illustrator"],
    objective: "Show range across common poster categories small businesses regularly need.",
    approach: "A set of concept posters spanning an Instagram promo, a corporate announcement, an event promotion, and a festive campaign — each with its own visual language.",
    outcome: "A varied reference set for what poster design across categories can look like.",
  },
  {
    id: "poster-collection-2",
    isReal: false,
    title: "Poster Collection — Restaurant, Real Estate, Product & Fitness",
    category: "Graphics",
    type: "Sample / Concept Work",
    role: "Graphic Designer",
    tools: ["Photoshop", "Illustrator"],
    objective: "Extend the poster range into industry-specific categories: hospitality, real estate, retail, fashion, and fitness.",
    approach: "Concept posters for a restaurant menu promo, a real estate listing, a product launch, a fashion campaign, and a gym/wellness push.",
    outcome: "A broader library demonstrating adaptability across very different brand tones.",
  },
  {
    id: "industry-posters",
    isReal: false,
    title: "Industry Posters & E-Commerce Banners",
    category: "Graphics",
    type: "Sample / Concept Work",
    role: "Graphic Designer",
    tools: ["Photoshop", "Illustrator"],
    objective: "Cover technology, education, and healthcare poster concepts alongside e-commerce web banners.",
    approach: "Concept work for a tech/product launch poster, a course/institution poster, a clinic/wellness poster, and a web store promo banner.",
    outcome: "Further range across sectors that commonly need fast-turnaround marketing graphics.",
  },
  {
    id: "video-3d",
    isReal: false,
    title: "Video Editing & 3D Product Renders",
    category: "Video",
    type: "Sample / Concept Work",
    role: "Video Editor & 3D Artist",
    tools: ["Premiere Pro", "Blender"],
    objective: "Demonstrate a before/after video grade and a 3D product render concept.",
    approach: "Raw footage graded and edited for pacing and colour, alongside a rendered 3D product concept built for presentation use.",
    outcome: "A concept reel showing the kind of polish video and 3D work can add to a launch.",
  },
];

export const projectCategories = ["All", "Web Development", "UI/UX", "Graphics", "Video"];

export type Skill = { name: string; level: number; group: string };

export const skills: Skill[] = [
  { name: "HTML", level: 95, group: "Development" },
  { name: "CSS", level: 92, group: "Development" },
  { name: "JavaScript", level: 90, group: "Development" },
  { name: "TypeScript", level: 82, group: "Development" },
  { name: "React", level: 90, group: "Development" },
  { name: "Next.js", level: 88, group: "Development" },
  { name: "Node.js", level: 80, group: "Development" },
  { name: "Express", level: 78, group: "Development" },
  { name: "MongoDB", level: 78, group: "Development" },
  { name: "PostgreSQL", level: 76, group: "Development" },
  { name: "Prisma", level: 80, group: "Development" },
  { name: "Tailwind CSS", level: 92, group: "Development" },
  { name: "Git & GitHub", level: 85, group: "Development" },
  { name: "Figma", level: 90, group: "Design" },
  { name: "Photoshop", level: 85, group: "Design" },
  { name: "Canva", level: 88, group: "Design" },
  { name: "Blender", level: 72, group: "Design" },
  { name: "Premiere Pro", level: 78, group: "Design" },
];

export const skillGroups = ["Development", "Design"];

export type Testimonial = {
  quote: string;
  name: string;
  role: string;
  isSample: true;
};

// NOTE: these are illustrative sample quotes carried over from the source
// portfolio brief, not verified statements from named clients. They are
// clearly labelled "Sample" in the UI. Replace with real, consented client
// quotes as they come in.
export const testimonials: Testimonial[] = [
  { quote: "Mohan redid our menu design and Instagram posts and our page finally looks like a real restaurant brand instead of a photo dump. Quick turnaround too.", name: "Aravind Ramesh", role: "Owner, Coastal Spice Kitchen", isSample: true },
  { quote: "We needed a logo and a simple brand kit before our launch. He asked good questions upfront, which meant almost no back-and-forth on revisions.", name: "Priya Natarajan", role: "Founder, Loomcraft Studio", isSample: true },
  { quote: "The property posters he designed for our listings actually got shared more on social media than our older ones. Clean, professional work.", name: "Karthik S.", role: "Marketing Lead, Vertex Realty", isSample: true },
  { quote: "Needed someone who could handle my Instagram content and a simple landing page together. Having one person do both kept everything consistent.", name: "Divya Suresh", role: "Independent Fitness Coach", isSample: true },
];

export type PricingTier = {
  name: string;
  price: string;
  popular?: boolean;
  features: string[];
};

export const pricingGroups: { title: string; note: string; tiers: PricingTier[] }[] = [
  {
    title: "Website & UI/UX Packages",
    note: "Final pricing depends on project scope, page count, and feature requirements — these are starting packages, confirmed after consultation.",
    tiers: [
      { name: "Basic", price: "₹8,000", features: ["1-page responsive landing page", "Mobile-friendly layout", "Contact form integration", "1 round of revisions", "5-day delivery"] },
      { name: "Standard", price: "₹18,000", popular: true, features: ["Up to 5 pages, custom UI design", "Full responsive development", "Basic on-page SEO setup", "2 rounds of revisions", "10–14 day delivery"] },
      { name: "Premium", price: "₹35,000", features: ["Up to 10 pages, full UI/UX system", "CMS or admin panel integration", "Advanced SEO optimisation", "3 rounds of revisions", "30 days post-launch support"] },
    ],
  },
  {
    title: "Graphic, Branding & Print Design",
    note: "Packages can be mixed and matched — for example, a logo plus a monthly social content package. Ask for a custom quote.",
    tiers: [
      { name: "Basic", price: "₹2,500", features: ["Logo design (3 concepts) — or —", "5 social media post designs — or —", "1 poster or flyer", "2 revision rounds"] },
      { name: "Standard", price: "₹6,000", popular: true, features: ["Logo + colour palette + fonts — or —", "Poster + flyer + banner bundle (5 pieces)", "15 social media post designs", "3 revision rounds"] },
      { name: "Premium", price: "₹12,000", features: ["Full brand identity + guideline doc", "Full print marketing bundle (10+ pieces)", "Monthly social content package (30 posts)", "Unlimited revisions within scope"] },
    ],
  },
  {
    title: "Video, 3D & Content Writing",
    note: "Video and 3D pricing varies with footage length, asset complexity, and revisions — confirmed after reviewing your brief.",
    tiers: [
      { name: "Basic", price: "₹2,000", features: ["Up to 2-min video edit — or —", "3 product 3D renders — or —", "1,000-word article", "1 revision round"] },
      { name: "Standard", price: "₹5,000", popular: true, features: ["Up to 5-min edit with motion graphics — or —", "3D modeling + render bundle (5 assets)", "5 blog articles or 20 product descriptions", "2 revision rounds"] },
      { name: "Premium", price: "₹10,000", features: ["Full video package (edit + motion + thumbnail)", "3D modeling + scene render + mockup bundle", "Monthly content package (web + blog + captions)", "Priority turnaround"] },
    ],
  },
];

export const faqs = [
  { q: "What kind of projects do you typically take on?", a: "Mostly startups, small businesses, and individuals who need a website, a brand identity, or ongoing design/content support — often a mix of several of these at once." },
  { q: "Do I need to know exactly what I want before reaching out?", a: "No. A short consultation call is the first step for a reason — we'll figure out scope and direction together based on your goals, not a pre-filled brief." },
  { q: "How long does a typical website take?", a: "A landing page usually takes about 5 days; a full multi-page site with custom UI typically runs 10–14 days, and larger builds with CMS or admin panels are scoped individually." },
  { q: "Can you handle both design and development?", a: "Yes — that's the core of how I work. I design the interface and build it into a working, deployed website rather than handing off a static mockup." },
  { q: "Do you offer ongoing support after launch?", a: "Yes. Premium web packages include 30 days of post-launch support, and I'm generally available afterward for small fixes and guidance as needed." },
  { q: "How does pricing work if I need more than one service?", a: "Packages can be mixed and matched — for example, a website plus a monthly social content package. Get in touch and I'll put together a custom quote." },
  { q: "What's included in the revision rounds?", a: "Each package lists a set number of revision rounds. These cover adjustments to the agreed scope; larger changes in direction are scoped separately to keep timelines realistic." },
  { q: "Do you work with clients outside India?", a: "Yes. Communication happens over call, email, and WhatsApp, so location isn't a barrier — timelines are agreed upfront regardless of time zone." },
  { q: "Can you build an online store, not just a brochure site?", a: "Yes — full-stack e-commerce builds with a real product catalogue, checkout flow, and database are part of the web development service." },
  { q: "What do you need from me to get started?", a: "A short brief on your business and goals, any existing brand assets (logo, colours, past materials), and availability for a quick consultation call." },
  { q: "Do you sign contracts or provide invoices?", a: "Yes, scope, timeline, and payment terms are confirmed in writing before work begins, and invoices are provided for every project." },
];

export const nav = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Skills", href: "#skills" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Pricing", href: "#pricing" },
  { label: "Contact", href: "#contact" },
];
