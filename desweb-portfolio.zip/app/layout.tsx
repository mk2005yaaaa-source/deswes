import type { Metadata } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import ScrollProgress from "@/components/ScrollProgress";
import CursorEffect from "@/components/CursorEffect";
import BackToTop from "@/components/BackToTop";
import WhatsAppButton from "@/components/WhatsAppButton";
import LoadingScreen from "@/components/LoadingScreen";
import ThemeProvider from "@/components/ThemeProvider";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-space-grotesk",
  display: "swap",
  weight: ["500", "600", "700"],
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
  weight: ["400", "500", "600"],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains-mono",
  display: "swap",
  weight: ["400", "500"],
});

export const metadata: Metadata = {
  metadataBase: new URL("https://desweb.dev"),
  title: {
    default: "desweb — Mohan Kumar | Web Design, Branding & Digital Studio",
    template: "%s | desweb",
  },
  description:
    "desweb is the freelance studio of Mohan Kumar — full-stack web design & development, UI/UX, branding, video, 3D, and content writing for growing businesses in Chennai and beyond.",
  keywords: [
    "desweb",
    "Mohan Kumar",
    "freelance web designer Chennai",
    "UI UX designer",
    "brand identity design",
    "Next.js developer India",
  ],
  authors: [{ name: "Mohan Kumar" }],
  icons: {
    icon: [
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
  },
  openGraph: {
    title: "desweb — Mohan Kumar | Web Design, Branding & Digital Studio",
    description:
      "Full-stack web design & development, UI/UX, branding, video, 3D, and content writing — one studio, twenty-five services.",
    url: "https://desweb.dev",
    siteName: "desweb",
    images: [{ url: "/logo-full.png", width: 895, height: 236, alt: "desweb" }],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "desweb — Mohan Kumar",
    description:
      "Full-stack web design & development, UI/UX, branding, video, 3D, and content writing.",
    images: ["/logo-full.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${spaceGrotesk.variable} ${inter.variable} ${jetbrainsMono.variable}`}>
      <body className="font-body bg-base text-ink antialiased">
        <ThemeProvider>
          <LoadingScreen />
          <ScrollProgress />
          <CursorEffect />
          {children}
          <WhatsAppButton />
          <BackToTop />
        </ThemeProvider>
      </body>
    </html>
  );
}
