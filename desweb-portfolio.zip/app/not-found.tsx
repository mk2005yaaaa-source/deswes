import Link from "next/link";
import Image from "next/image";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-6 text-center px-6 grid-bg">
      <Image src="/logo-icon.png" alt="desweb" width={56} height={56} />
      <div>
        <p className="font-mono text-brand-accent text-sm mb-2">404</p>
        <h1 className="font-display font-bold text-3xl sm:text-4xl mb-3">
          This page doesn&apos;t exist.
        </h1>
        <p className="text-ink-muted max-w-md mx-auto">
          The page you&apos;re looking for may have moved or never existed.
          Let&apos;s get you back on track.
        </p>
      </div>
      <Link
        href="/"
        className="inline-flex items-center px-6 py-3 rounded-xl bg-brand-primary text-white font-medium hover:bg-brand-primary/90 hover:shadow-glow-primary transition-all"
      >
        Back to Home
      </Link>
    </div>
  );
}
