"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Globe, LayoutTemplate, MousePointerClick, Palette, Fingerprint, Image as ImageIcon,
  FileText, Layers3, Rows3, PanelTop, Youtube, Film, Sparkles, Box, PackageSearch,
  Camera, PackageOpen, FileBadge, Files, Presentation, PenLine, ScrollText, Search, Tag, Share2,
  ArrowRight,
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import { services, serviceCategories, type Service } from "@/lib/data";

const ICON_MAP: Record<string, any> = {
  "web-design-dev": Globe,
  uiux: LayoutTemplate,
  "landing-page": MousePointerClick,
  logo: Palette,
  "brand-identity": Fingerprint,
  posters: ImageIcon,
  flyers: FileText,
  brochures: Layers3,
  banners: Rows3,
  "social-media": PanelTop,
  "yt-thumbnails": Youtube,
  "video-editing": Film,
  "motion-graphics": Sparkles,
  "3d-modeling": Box,
  "3d-product-modeling": PackageSearch,
  "product-rendering": Camera,
  "product-mockups": PackageOpen,
  resume: FileBadge,
  "business-docs": Files,
  presentations: Presentation,
  "content-writing": PenLine,
  "website-copy": ScrollText,
  "seo-blog": Search,
  "product-desc": Tag,
  "social-copy": Share2,
};

function ServiceCard({ service, index }: { service: Service; index: number }) {
  const Icon = ICON_MAP[service.id] ?? Globe;
  return (
    <ScrollReveal delay={(index % 6) * 0.05}>
      <div className="group relative glass rounded-2xl p-6 h-full flex flex-col hover:-translate-y-1.5 hover:shadow-glow-primary hover:border-brand-primary/40 transition-all duration-300">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-brand-primary/25 to-brand-secondary/25 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
          <Icon size={22} className="text-brand-accent" />
        </div>
        <span className="font-mono text-[11px] text-ink-faint mb-1">{service.category}</span>
        <h3 className="font-display font-semibold text-lg mb-2 leading-snug">{service.title}</h3>
        <p className="text-sm text-ink-muted leading-relaxed mb-4 flex-1">{service.description}</p>
        <ul className="space-y-1.5 mb-5">
          {service.benefits.slice(0, 2).map((b) => (
            <li key={b} className="flex items-start gap-2 text-xs text-ink-muted">
              <span className="w-1 h-1 rounded-full bg-brand-accent mt-1.5 shrink-0" />
              {b}
            </li>
          ))}
        </ul>
        <a
          href="#contact"
          className="inline-flex items-center gap-1.5 text-sm font-medium text-brand-primary group-hover:gap-2.5 transition-all"
        >
          Get a quote
          <ArrowRight size={14} />
        </a>
      </div>
    </ScrollReveal>
  );
}

export default function Services() {
  const [category, setCategory] = useState("All");
  const filtered =
    category === "All" ? services : services.filter((s) => s.category === category);

  return (
    <section id="services" className="section-pad relative">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">// what-i-offer</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-3">Services</h2>
          <p className="text-ink-muted max-w-2xl mb-8">
            Twenty-five services across six disciplines — web, branding, print &amp; social
            design, video &amp; motion, 3D visualization, and content writing.
          </p>
        </ScrollReveal>

        <div className="flex flex-wrap gap-2 mb-10">
          {serviceCategories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all border ${
                category === c
                  ? "bg-brand-primary border-brand-primary text-white"
                  : "border-white/10 text-ink-muted hover:text-ink hover:border-white/20"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <motion.div
          layout
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((service, i) => (
              <motion.div
                key={service.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.25 }}
              >
                <ServiceCard service={service} index={i} />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </section>
  );
}
