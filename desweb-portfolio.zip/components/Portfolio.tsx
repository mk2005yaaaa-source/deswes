"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ExternalLink, Github, Code2 } from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import { projects, projectCategories, type Project } from "@/lib/data";

function ProjectThumb({ project }: { project: Project }) {
  return (
    <div className="relative h-44 rounded-xl overflow-hidden bg-gradient-to-br from-base-card to-base flex items-center justify-center border border-white/5">
      <div className="absolute inset-0 grid-bg opacity-40" />
      <div className="relative z-10 flex flex-col items-center gap-2 px-4 text-center">
        <Code2 size={26} className="text-brand-primary/70" />
        <span className="font-mono text-[11px] text-ink-faint">{project.category}</span>
      </div>
      <div className="absolute top-3 left-3">
        {project.isReal ? (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-brand-accent/20 text-brand-accent border border-brand-accent/30">
            REAL PROJECT
          </span>
        ) : (
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-ink-faint border border-white/10">
            CONCEPT
          </span>
        )}
      </div>
    </div>
  );
}

export default function Portfolio() {
  const [category, setCategory] = useState("All");
  const [active, setActive] = useState<Project | null>(null);
  const filtered =
    category === "All" ? projects : projects.filter((p) => p.category === category);

  return (
    <section id="portfolio" className="section-pad relative bg-base-card/30">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">// selected-work</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-3">Portfolio</h2>
          <p className="text-ink-muted max-w-2xl mb-8">
            A mix of real, shipped projects and sample concept work created to demonstrate
            range across web, branding, print, video, and 3D. Real projects are clearly marked.
          </p>
        </ScrollReveal>

        <div className="flex flex-wrap gap-2 mb-10">
          {projectCategories.map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all border ${
                category === c
                  ? "bg-brand-primary border-brand-primary text-white"
                  : "border-white/10 text-ink-muted hover:text-ink hover:border-white/20"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filtered.map((project, i) => (
              <motion.button
                key={project.id}
                layout
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3, delay: (i % 6) * 0.04 }}
                onClick={() => setActive(project)}
                data-cursor-hover
                className="text-left glass rounded-2xl p-4 group hover:-translate-y-1.5 hover:border-brand-primary/40 hover:shadow-glow-primary transition-all duration-300"
              >
                <ProjectThumb project={project} />
                <h3 className="font-display font-semibold text-base mt-4 mb-1.5 group-hover:text-brand-accent transition-colors">
                  {project.title}
                </h3>
                <p className="text-xs text-ink-faint">{project.type}</p>
              </motion.button>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      <AnimatePresence>
        {active && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[90] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setActive(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 20 }}
              transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
              onClick={(e) => e.stopPropagation()}
              className="glass-strong rounded-3xl max-w-2xl w-full max-h-[85vh] overflow-y-auto p-7 sm:p-9"
            >
              <div className="flex items-start justify-between mb-5">
                <div>
                  {active.isReal ? (
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-brand-accent/20 text-brand-accent border border-brand-accent/30">
                      REAL PROJECT
                    </span>
                  ) : (
                    <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-white/10 text-ink-faint border border-white/10">
                      SAMPLE / CONCEPT
                    </span>
                  )}
                  <h3 className="font-display font-bold text-2xl mt-3">{active.title}</h3>
                  <p className="text-sm text-ink-faint mt-1">{active.type}</p>
                </div>
                <button
                  onClick={() => setActive(null)}
                  aria-label="Close project details"
                  className="w-9 h-9 rounded-full flex items-center justify-center text-ink-muted hover:text-ink hover:bg-white/5 shrink-0"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="grid sm:grid-cols-3 gap-3 mb-6 text-sm">
                <div>
                  <p className="text-xs text-ink-faint uppercase mb-1">Role</p>
                  <p className="text-ink font-medium">{active.role}</p>
                </div>
                <div className="sm:col-span-2">
                  <p className="text-xs text-ink-faint uppercase mb-1">Tools</p>
                  <div className="flex flex-wrap gap-1.5">
                    {active.tools.map((t) => (
                      <span key={t} className="px-2 py-0.5 rounded-md bg-white/5 text-xs text-ink-muted">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-4 text-sm text-ink-muted leading-relaxed">
                <div>
                  <p className="font-display font-semibold text-ink mb-1">Objective</p>
                  <p>{active.objective}</p>
                </div>
                <div>
                  <p className="font-display font-semibold text-ink mb-1">Approach</p>
                  <p>{active.approach}</p>
                </div>
                <div>
                  <p className="font-display font-semibold text-ink mb-1">Outcome</p>
                  <p>{active.outcome}</p>
                </div>
              </div>

              {active.isReal && (
                <div className="flex flex-wrap gap-3 mt-7">
                  <a
                    href="#contact"
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg bg-brand-primary text-white text-sm font-medium hover:bg-brand-primary/90 transition-colors"
                  >
                    <ExternalLink size={15} />
                    Ask about this project
                  </a>
                  <a
                    href="https://github.com/Mohan449"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg glass text-sm font-medium hover:border-white/20 transition-colors"
                  >
                    <Github size={15} />
                    View GitHub
                  </a>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
