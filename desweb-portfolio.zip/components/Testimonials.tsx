"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Quote, ChevronLeft, ChevronRight, Info } from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import { testimonials } from "@/lib/data";

export default function Testimonials() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((i) => (i + 1) % testimonials.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setIndex((i) => (i + 1) % testimonials.length);
  const prev = () => setIndex((i) => (i - 1 + testimonials.length) % testimonials.length);

  const t = testimonials[index];

  return (
    <section id="testimonials" className="section-pad relative bg-base-card/30">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">// client-feedback</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-3">
            What Clients Say
          </h2>
          <div className="flex items-start gap-2 max-w-2xl mb-12 text-ink-faint text-sm">
            <Info size={16} className="shrink-0 mt-0.5" />
            <p>
              Sample testimonials illustrating the kind of feedback this style of work aims
              for — to be replaced with real client quotes as the review base grows.
            </p>
          </div>
        </ScrollReveal>

        <ScrollReveal>
          <div className="relative max-w-2xl mx-auto">
            <div className="glass-strong rounded-3xl p-8 sm:p-10 min-h-[260px] flex flex-col justify-between">
              <div>
                <Quote size={30} className="text-brand-accent/50 mb-4" />
                <AnimatePresence mode="wait">
                  <motion.p
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.35 }}
                    className="text-lg sm:text-xl leading-relaxed text-ink"
                  >
                    &ldquo;{t.quote}&rdquo;
                  </motion.p>
                </AnimatePresence>
              </div>
              <div className="flex items-center justify-between mt-8">
                <div>
                  <p className="font-display font-semibold">{t.name}</p>
                  <p className="text-sm text-ink-faint">{t.role}</p>
                  <span className="inline-block mt-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/5 text-ink-faint border border-white/10">
                    Sample quote
                  </span>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={prev}
                    aria-label="Previous testimonial"
                    className="w-9 h-9 rounded-full glass flex items-center justify-center hover:border-brand-primary/40"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <button
                    onClick={next}
                    aria-label="Next testimonial"
                    className="w-9 h-9 rounded-full glass flex items-center justify-center hover:border-brand-primary/40"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            </div>
            <div className="flex justify-center gap-2 mt-5">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setIndex(i)}
                  aria-label={`Go to testimonial ${i + 1}`}
                  className={`h-1.5 rounded-full transition-all ${
                    i === index ? "w-6 bg-brand-accent" : "w-1.5 bg-white/15"
                  }`}
                />
              ))}
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
