"use client";

import { useState } from "react";
import { Mail, Phone, Github, MapPin, Send, CheckCircle2 } from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import { brand } from "@/lib/data";

const CONTACT_ITEMS = [
  { icon: Mail, label: "Email", value: brand.email, href: `mailto:${brand.email}` },
  { icon: Phone, label: "Phone / WhatsApp", value: brand.phone, href: `https://wa.me/${brand.whatsapp}` },
  { icon: Github, label: "GitHub", value: "github.com/Mohan449", href: brand.github },
  { icon: MapPin, label: "Location", value: brand.location, href: undefined },
];

export default function Contact() {
  const [status, setStatus] = useState<"idle" | "sent">("idle");
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    // No backend is wired up yet — this opens a pre-filled email as a
    // reliable fallback so messages always reach the inbox above.
    const subject = encodeURIComponent(`New project inquiry from ${form.name || "your site"}`);
    const body = encodeURIComponent(
      `${form.message}\n\n— ${form.name} (${form.email})`
    );
    window.location.href = `mailto:${brand.email}?subject=${subject}&body=${body}`;
    setStatus("sent");
  }

  return (
    <section id="contact" className="section-pad relative">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">// lets-work-together</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-3">
            Get In Touch
          </h2>
          <p className="text-ink-muted max-w-2xl mb-12">
            Thank you for taking the time to look through this portfolio. If any of this
            work is a fit for what you&apos;re building, I&apos;d love to hear from you.
          </p>
        </ScrollReveal>

        <div className="grid lg:grid-cols-[1fr_1.15fr] gap-10">
          <ScrollReveal>
            <div className="space-y-4">
              {CONTACT_ITEMS.map((item) => {
                const Icon = item.icon;
                const content = (
                  <div className="flex items-center gap-4 glass rounded-2xl p-5 hover:border-brand-primary/40 transition-colors">
                    <div className="w-11 h-11 rounded-xl bg-brand-accent/15 flex items-center justify-center shrink-0">
                      <Icon size={19} className="text-brand-accent" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs text-ink-faint uppercase tracking-wide">{item.label}</p>
                      <p className="text-sm sm:text-[15px] font-medium text-ink truncate">
                        {item.value}
                      </p>
                    </div>
                  </div>
                );
                return item.href ? (
                  <a key={item.label} href={item.href} target="_blank" rel="noopener noreferrer" className="block">
                    {content}
                  </a>
                ) : (
                  <div key={item.label}>{content}</div>
                );
              })}
            </div>
          </ScrollReveal>

          <ScrollReveal delay={0.1}>
            <div className="glass-strong rounded-3xl p-7 sm:p-9">
              {status === "sent" ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-10">
                  <CheckCircle2 size={40} className="text-brand-success mb-4" />
                  <p className="font-display font-semibold text-lg mb-1">
                    Your email app should be opening
                  </p>
                  <p className="text-sm text-ink-muted max-w-sm">
                    If nothing happened, email me directly at{" "}
                    <a href={`mailto:${brand.email}`} className="text-brand-accent">
                      {brand.email}
                    </a>
                    .
                  </p>
                  <button
                    onClick={() => setStatus("idle")}
                    className="mt-6 text-sm text-brand-primary font-medium"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2">
                      Your name
                    </label>
                    <input
                      id="name"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-ink placeholder:text-ink-faint focus:border-brand-primary/60 outline-none transition-colors"
                      placeholder="Aravind Ramesh"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2">
                      Email address
                    </label>
                    <input
                      id="email"
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-ink placeholder:text-ink-faint focus:border-brand-primary/60 outline-none transition-colors"
                      placeholder="you@company.com"
                    />
                  </div>
                  <div>
                    <label htmlFor="message" className="block text-sm font-medium mb-2">
                      Project details
                    </label>
                    <textarea
                      id="message"
                      required
                      rows={5}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-sm text-ink placeholder:text-ink-faint focus:border-brand-primary/60 outline-none transition-colors resize-none"
                      placeholder="Tell me a bit about your business and what you need."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-brand-primary text-white font-medium hover:bg-brand-primary/90 hover:shadow-glow-primary transition-all"
                  >
                    Send Message
                    <Send size={16} />
                  </button>
                </form>
              )}
            </div>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
