import Image from "next/image";
import { Github, Mail, Phone } from "lucide-react";
import { nav, brand } from "@/lib/data";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/5">
      <div className="container-x py-14">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10">
          <div>
            <a href="#home" className="inline-flex items-center gap-2 mb-4">
              <Image src="/logo-icon.png" alt="" width={32} height={32} />
              <span className="font-display font-bold text-lg">
                des<span className="text-brand-accent">web</span>
              </span>
            </a>
            <p className="text-sm text-ink-muted leading-relaxed max-w-xs">
              {brand.tagline}
            </p>
          </div>

          <div>
            <h4 className="font-display font-semibold text-sm mb-4 text-ink-faint uppercase tracking-wide">
              Quick Links
            </h4>
            <ul className="space-y-2.5">
              {nav.slice(0, 5).map((n) => (
                <li key={n.href}>
                  <a href={n.href} className="text-sm text-ink-muted hover:text-brand-accent transition-colors">
                    {n.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-sm mb-4 text-ink-faint uppercase tracking-wide">
              Get in Touch
            </h4>
            <ul className="space-y-2.5">
              <li>
                <a href={`mailto:${brand.email}`} className="flex items-center gap-2 text-sm text-ink-muted hover:text-brand-accent transition-colors">
                  <Mail size={14} /> {brand.email}
                </a>
              </li>
              <li>
                <a href={`https://wa.me/${brand.whatsapp}`} className="flex items-center gap-2 text-sm text-ink-muted hover:text-brand-accent transition-colors">
                  <Phone size={14} /> {brand.phone}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-sm mb-4 text-ink-faint uppercase tracking-wide">
              Elsewhere
            </h4>
            <a
              href={brand.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="inline-flex w-10 h-10 rounded-full glass items-center justify-center hover:border-brand-accent/40 hover:text-brand-accent transition-colors"
            >
              <Github size={17} />
            </a>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-ink-faint">
          <p>© {year} desweb · {brand.person}. All rights reserved.</p>
          <p>{brand.location}</p>
        </div>
      </div>
    </footer>
  );
}
