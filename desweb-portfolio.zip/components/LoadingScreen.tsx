"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import Image from "next/image";

const LINES = ["init desweb studio", "loading assets", "ready"];

export default function LoadingScreen() {
  const [visible, setVisible] = useState(true);
  const [lineIndex, setLineIndex] = useState(0);

  useEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion) {
      setVisible(false);
      return;
    }
    const lineTimer = setInterval(() => {
      setLineIndex((i) => Math.min(i + 1, LINES.length - 1));
    }, 420);
    const doneTimer = setTimeout(() => setVisible(false), 1600);
    return () => {
      clearInterval(lineTimer);
      clearTimeout(doneTimer);
    };
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className="fixed inset-0 z-[200] bg-base flex flex-col items-center justify-center gap-6"
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            <Image
              src="/logo-icon.png"
              alt="desweb"
              width={64}
              height={64}
              priority
              className="animate-float-slow"
            />
          </motion.div>
          <div className="font-mono text-sm text-ink-muted h-5">
            <span>$ {LINES[lineIndex]}</span>
            <span className="terminal-caret" />
          </div>
          <div className="w-48 h-[3px] bg-white/10 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-brand-primary via-brand-secondary to-brand-accent"
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 1.5, ease: "easeInOut" }}
            />
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
