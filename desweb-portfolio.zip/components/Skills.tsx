"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import ScrollReveal from "./ScrollReveal";
import { skills, skillGroups } from "@/lib/data";

function SkillBar({ name, level, delay }: { name: string; level: number; delay: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-40px" });

  return (
    <div ref={ref}>
      <div className="flex justify-between items-baseline mb-1.5">
        <span className="text-sm font-medium text-ink">{name}</span>
        <span className="font-mono text-xs text-brand-accent">{level}%</span>
      </div>
      <div className="h-2 rounded-full bg-white/5 overflow-hidden">
        <motion.div
          className="h-full rounded-full bg-gradient-to-r from-brand-primary to-brand-secondary"
          initial={{ width: "0%" }}
          animate={isInView ? { width: `${level}%` } : {}}
          transition={{ duration: 1, delay, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}

export default function Skills() {
  return (
    <section id="skills" className="section-pad relative">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">// skill-tree</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-12">Skills</h2>
        </ScrollReveal>

        <div className="grid md:grid-cols-2 gap-x-12 gap-y-10">
          {skillGroups.map((group) => (
            <div key={group}>
              <h3 className="font-display font-semibold text-lg mb-6 text-brand-accent">
                {group}
              </h3>
              <div className="space-y-5">
                {skills
                  .filter((s) => s.group === group)
                  .map((s, i) => (
                    <SkillBar key={s.name} name={s.name} level={s.level} delay={i * 0.05} />
                  ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
