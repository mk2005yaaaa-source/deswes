"use client";

import { motion } from "framer-motion";
import { MessageCircle } from "lucide-react";
import { brand } from "@/lib/data";

export default function WhatsAppButton() {
  return (
    <motion.a
      href={`https://wa.me/${brand.whatsapp}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Message on WhatsApp"
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 1.8, duration: 0.4 }}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.95 }}
      className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-brand-success flex items-center justify-center shadow-lg shadow-brand-success/30"
    >
      <MessageCircle size={26} className="text-white" fill="currentColor" strokeWidth={0} />
    </motion.a>
  );
}
