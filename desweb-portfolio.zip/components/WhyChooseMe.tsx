"use client";

import {
  Users, Clock, Layers, Sparkles, MessageSquare, Wallet, LifeBuoy, PenTool,
} from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import { whyChooseMe } from "@/lib/data";

const ICONS = [Users, Clock, Layers, Sparkles, MessageSquare, Wallet, LifeBuoy, PenTool];

export default function WhyChooseMe() {
  return (
    <section className="section-pad relative bg-base-card/30">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">// why-work-with-me</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-3">
            Why Choose Me
          </h2>
          <p className="text-ink-muted max-w-2xl mb-12">
            Eight reasons small businesses and individual clients choose to work with me
            over a larger agency.
          </p>
        </ScrollReveal>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {whyChooseMe.map((item, i) => {
            const Icon = ICONS[i % ICONS.length];
            return (
              <ScrollReveal key={item.title} delay={(i % 4) * 0.06}>
                <div className="glass rounded-2xl p-6 h-full hover:-translate-y-1 hover:border-brand-primary/40 hover:shadow-glow-primary transition-all duration-300">
                  <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-brand-primary/20 to-brand-secondary/20 flex items-center justify-center mb-4">
                    <Icon size={20} className="text-brand-accent" />
                  </div>
                  <h3 className="font-display font-semibold text-base mb-2">{item.title}</h3>
                  <p className="text-sm text-ink-muted leading-relaxed">{item.description}</p>
                </div>
              </ScrollReveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
