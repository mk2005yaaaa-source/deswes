"use client";

import ScrollReveal from "./ScrollReveal";
import AnimatedCounter from "./AnimatedCounter";
import { about, stats, process } from "@/lib/data";

export default function About() {
  return (
    <section id="about" className="section-pad relative">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">{about.eyebrow}</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-12">
            {about.heading}
          </h2>
        </ScrollReveal>

        <div className="grid lg:grid-cols-[1.3fr_1fr] gap-12">
          <div>
            <ScrollReveal>
              <div className="space-y-5 text-ink-muted leading-relaxed text-[15px] sm:text-base">
                {about.paragraphs.map((p, i) => (
                  <p key={i} className={i === 0 ? "text-lg text-ink" : ""}>
                    {p}
                  </p>
                ))}
              </div>
            </ScrollReveal>

            <ScrollReveal delay={0.15}>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-12">
                {stats.map((s) => (
                  <div key={s.label} className="glass rounded-2xl p-5 text-center">
                    <div className="text-3xl sm:text-4xl text-brand-accent">
                      <AnimatedCounter value={s.value} suffix={s.suffix} />
                    </div>
                    <p className="text-xs sm:text-sm text-ink-muted mt-2">{s.label}</p>
                  </div>
                ))}
              </div>
            </ScrollReveal>
          </div>

          <ScrollReveal delay={0.1}>
            <div className="glass-strong rounded-3xl p-6 sm:p-7 h-full">
              <p className="font-mono text-xs text-brand-accent mb-5">// profile.json</p>
              <dl className="space-y-5">
                {about.meta.map((m) => (
                  <div key={m.label} className="border-b border-white/5 pb-4 last:border-0 last:pb-0">
                    <dt className="text-xs uppercase tracking-wide text-ink-faint mb-1">
                      {m.label}
                    </dt>
                    <dd className="text-sm sm:text-[15px] text-ink font-medium">{m.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </ScrollReveal>
        </div>

        <ScrollReveal delay={0.1} className="mt-20">
          <h3 className="font-display font-semibold text-2xl mb-10">
            How we&apos;ll work together
          </h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {process.map((p, i) => (
              <ScrollReveal key={p.step} delay={i * 0.05}>
                <div className="glass rounded-2xl p-5 h-full hover:border-brand-primary/40 transition-colors group">
                  <span className="font-mono text-xs text-brand-primary">{p.step}</span>
                  <h4 className="font-display font-semibold text-base mt-2 mb-1.5 group-hover:text-brand-accent transition-colors">
                    {p.title}
                  </h4>
                  <p className="text-sm text-ink-muted leading-relaxed">{p.description}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
