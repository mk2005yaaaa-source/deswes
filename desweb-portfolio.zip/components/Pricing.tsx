"use client";

import { Check } from "lucide-react";
import ScrollReveal from "./ScrollReveal";
import { pricingGroups } from "@/lib/data";

export default function Pricing() {
  return (
    <section id="pricing" className="section-pad relative">
      <div className="container-x">
        <ScrollReveal>
          <p className="eyebrow">// pricing</p>
          <h2 className="font-display font-bold text-3xl sm:text-4xl mt-2 mb-3">Pricing</h2>
          <p className="text-ink-muted max-w-2xl mb-14">
            Starting packages across every discipline. Final pricing is always confirmed
            after a short consultation call.
          </p>
        </ScrollReveal>

        <div className="space-y-16">
          {pricingGroups.map((group) => (
            <div key={group.title}>
              <ScrollReveal>
                <h3 className="font-display font-semibold text-xl mb-1.5">{group.title}</h3>
                <p className="text-sm text-ink-faint mb-8 max-w-2xl">{group.note}</p>
              </ScrollReveal>
              <div className="grid md:grid-cols-3 gap-6">
                {group.tiers.map((tier, i) => (
                  <ScrollReveal key={tier.name} delay={i * 0.08}>
                    <div
                      className={`relative rounded-3xl p-7 h-full flex flex-col transition-all duration-300 ${
                        tier.popular
                          ? "glass-strong border-2 border-brand-primary/50 shadow-glow-primary lg:scale-[1.03]"
                          : "glass hover:border-white/20"
                      }`}
                    >
                      {tier.popular && (
                        <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-brand-primary text-white text-xs font-medium">
                          Most Popular
                        </span>
                      )}
                      <h4 className="font-display font-semibold text-lg">{tier.name}</h4>
                      <p className="font-display font-bold text-3xl mt-2 mb-1">
                        {tier.price}
                      </p>
                      <p className="text-xs text-ink-faint mb-6">starting</p>
                      <ul className="space-y-3 flex-1 mb-7">
                        {tier.features.map((f) => (
                          <li key={f} className="flex items-start gap-2.5 text-sm text-ink-muted">
                            <Check size={16} className="text-brand-success shrink-0 mt-0.5" />
                            <span>{f}</span>
                          </li>
                        ))}
                      </ul>
                      <a
                        href="#contact"
                        className={`inline-flex items-center justify-center px-5 py-3 rounded-xl text-sm font-medium transition-all ${
                          tier.popular
                            ? "bg-brand-primary text-white hover:bg-brand-primary/90 hover:shadow-glow-primary"
                            : "glass-strong text-ink hover:border-brand-accent/40"
                        }`}
                      >
                        Get Started
                      </a>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
