"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight, Download, ChevronDown } from "lucide-react";
import { brand } from "@/lib/data";

const ROLES = brand.disciplines;

function TypedRoles() {
  const [roleIndex, setRoleIndex] = useState(0);
  const [text, setText] = useState("");
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = ROLES[roleIndex];
    const speed = deleting ? 35 : 65;
    const timeout = setTimeout(() => {
      if (!deleting) {
        if (text.length < current.length) {
          setText(current.slice(0, text.length + 1));
        } else {
          setTimeout(() => setDeleting(true), 1200);
        }
      } else {
        if (text.length > 0) {
          setText(current.slice(0, text.length - 1));
        } else {
          setDeleting(false);
          setRoleIndex((i) => (i + 1) % ROLES.length);
        }
      }
    }, speed);
    return () => clearTimeout(timeout);
  }, [text, deleting, roleIndex]);

  return (
    <span className="text-gradient">
      {text}
      <span className="terminal-caret" aria-hidden="true" />
    </span>
  );
}

export default function Hero() {
  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center pt-28 pb-16 overflow-hidden"
    >
      <div className="absolute inset-0 grid-bg" aria-hidden="true" />
      <div className="absolute inset-0 bg-glow-radial" aria-hidden="true" />
      <div
        className="absolute -top-32 -right-32 w-[28rem] h-[28rem] rounded-full bg-accent-glow animate-float-slow"
        aria-hidden="true"
      />
      <div
        className="absolute top-1/3 -left-24 w-72 h-72 rounded-full bg-brand-secondary/10 blur-3xl animate-float"
        aria-hidden="true"
      />

      <div className="container-x relative z-10">
        <div className="grid lg:grid-cols-[1.15fr_0.85fr] gap-14 items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass mb-7"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-brand-success animate-pulse" />
              <span className="font-mono text-xs text-ink-muted">
                available for new projects
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display font-bold text-4xl sm:text-5xl lg:text-6xl leading-[1.06] tracking-tight"
            >
              Mohan Kumar builds
              <br />
              digital work under{" "}
              <span className="whitespace-nowrap">
                des<span className="text-brand-accent">web</span>
              </span>
              .
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mt-5 font-mono text-lg sm:text-xl text-ink-muted h-8"
            >
              <TypedRoles />
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="mt-6 text-ink-muted text-lg max-w-xl leading-relaxed"
            >
              {brand.description}
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-9 flex flex-wrap gap-3"
            >
              <a
                href="#portfolio"
                className="group inline-flex items-center gap-2 px-6 py-3.5 rounded-xl bg-brand-primary text-white font-medium hover:shadow-glow-primary hover:bg-brand-primary/90 transition-all"
              >
                View Portfolio
                <ArrowRight size={17} className="group-hover:translate-x-0.5 transition-transform" />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl glass-strong text-ink font-medium hover:border-brand-accent/50 hover:shadow-glow-accent transition-all"
              >
                Hire Me
              </a>
              <a
                href="/logo-full.png"
                download
                className="inline-flex items-center gap-2 px-6 py-3.5 rounded-xl text-ink-muted font-medium hover:text-ink transition-colors"
              >
                <Download size={17} />
                Download Portfolio
              </a>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="relative flex justify-center lg:justify-end"
          >
            <div className="relative w-64 h-64 sm:w-80 sm:h-80">
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-br from-brand-primary/20 via-brand-secondary/15 to-brand-accent/20 blur-2xl" />
              <div className="relative w-full h-full rounded-3xl glass-strong flex items-center justify-center p-10 animate-float">
                <Image
                  src="/logo-full.png"
                  alt="desweb"
                  width={895}
                  height={236}
                  priority
                  className="w-full h-auto drop-shadow-2xl"
                />
              </div>
              <div className="absolute -bottom-5 -left-5 glass-strong rounded-2xl px-4 py-3 shadow-glass">
                <p className="font-mono text-xs text-brand-accent">$ status</p>
                <p className="text-sm font-medium mt-0.5">Open for work</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <motion.a
        href="#about"
        aria-label="Scroll to About section"
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
        className="hidden sm:flex absolute bottom-8 left-1/2 -translate-x-1/2 flex-col items-center gap-1 text-ink-faint hover:text-ink-muted"
      >
        <span className="font-mono text-[11px]">scroll</span>
        <ChevronDown size={18} />
      </motion.a>
    </section>
  );
}
