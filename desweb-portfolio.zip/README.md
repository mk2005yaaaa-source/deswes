# desweb — Portfolio Website

Freelance portfolio site for **Mohan Kumar / desweb**, built with Next.js 14 (App Router),
TypeScript, Tailwind CSS, and Framer Motion.

## Getting started

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Build for production

```bash
npm run build
npm run start
```

## Deploying

This project is ready to deploy on [Vercel](https://vercel.com) with zero config —
push it to a GitHub repo and import it, or run:

```bash
npx vercel
```

## Project structure

```
app/                  Routes, layout, global styles, SEO files
  layout.tsx           Root layout, fonts, metadata
  page.tsx             Homepage — assembles all sections
  not-found.tsx         Custom 404
  sitemap.ts / robots.ts / manifest.ts
components/           All UI sections and widgets
lib/data.ts            Single source of truth for all site copy/content
public/                Logo, favicons, app icons
```

## Editing content

Almost everything on the site — services, projects, skills, pricing, FAQ,
contact details — lives in **`lib/data.ts`**. Edit that file to update copy
without touching component code.

### A note on testimonials

The four testimonials in `lib/data.ts` are carried over from the original
portfolio brief and are explicitly marked there as **sample / illustrative
quotes**, not verified statements from real, named clients. The site labels
them "Sample quote" in the UI for the same reason. Please only remove that
label once you have real, consented quotes from actual clients — presenting
invented quotes as genuine reviews can mislead visitors and create legal risk
(fake testimonials/reviews are restricted in many jurisdictions, including
under FTC rules in the US).

### Swapping the logo

Logo assets live in `public/`:
- `logo-full.png` — full lockup (icon + wordmark), used in the hero
- `logo-icon.png` — icon mark only, used in the navbar, footer, and loading screen
- `favicon-*.png`, `apple-touch-icon.png`, `android-chrome-*.png` — generated from the icon mark

Replace these files (keeping the same names) to update branding everywhere at once.

## Before going live

- [ ] Add real Instagram handle and any other social links in `lib/data.ts`
- [ ] Swap sample testimonials for real client quotes, or remove the section
- [ ] Update `metadataBase` URL in `app/layout.tsx` to your real domain
- [ ] Wire the contact form to an actual backend/email service if you want
      submissions delivered without relying on the visitor's own email client
- [ ] Run `npm run build` and check for a clean Lighthouse score
